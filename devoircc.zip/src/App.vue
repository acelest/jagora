<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
 <MonComposant></MonComposant>
 </div>
</template>

<script>
 
export default {
  name: 'App',
  components: {
    'MonComposant': Moncomposant
  
  }
}

</script>
<style>
#app {
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing:grayscale;
  text-align: center;
  color: darkgray;
  margin-top: 60px;
}

</style>
