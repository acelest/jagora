<template>
    <div>
        <p>>{{txt}}</p>
        <eleves v-bind:nom="nom"></eleves>
       
        </div>
</template>
<script>
import Liste from './Liste.vue'
export default {
    name:'MonContenu',
    data(){
         return {
            txt: 'Je suis un texte',
            }
            
        },
        components:{
            'liste':Liste
            
        }
    }    

</script>

<style>

</style>