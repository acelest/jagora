<template>
    <!-- <div>{{txt}}</div> -->
<ul class="eleves">
    <li v-for="(note, index) in notes " v-bind:key="index">{{ note }}</li>
</ul>

<p> {{ nom }} </p>
<p>{{ reversing() }}</p>
</template>
<script>
export default { 
    name:'Liste',
    data (){
        return {
                notes:['math 18','francais 14','informatique 17']
                }
            },
            props: ['prenom'],
            methods: {
                reversing: function(){
                    return this.nom.split('').reverse().join('')
                }
            }
        }
          

</script>

<style scoped>
</style>